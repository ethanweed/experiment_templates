// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "files": "happyf.jpeg",
          "emotion": "happy",
          "word": "jesle",
          "CR": "no"
        },
        {
          "files": "happym.jpeg",
          "emotion": "happy",
          "word": "æsel",
          "CR": "yes"
        },
        {
          "files": "sadf.jpeg",
          "emotion": "sad",
          "word": "aktiv",
          "CR": "yes"
        },
        {
          "files": "sadm.jpeg",
          "emotion": "sad",
          "word": "åbligt",
          "CR": "no"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {
        "happyf.jpeg": "embedded\u002Fb4ff102fb08de43ff1995674e7034ae9ae72cda5d16cab36fc140f2e886bc2de.jpeg",
        "happym.jpeg": "embedded\u002Fc007b865704b726973f9c61d4a369d9efd72cb9f6c8b818b3540b6cbd266d954.jpeg",
        "sadf.jpeg": "embedded\u002F5b2cbd93f05c3880bb3616dace075f104048a6c1150da0e03d3a687bbf716688.jpeg",
        "sadm.jpeg": "embedded\u002F82b22ec43afb56b94542399c8b3cf2bf82a828dda7b8f63afc91dc327810bd51.jpeg"
      },
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {
          "": ""
        },
        "parameters": {},
        "messageHandlers": {},
        "title": "Sequence",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 150,
                "top": 175,
                "angle": 0,
                "width": 100,
                "height": 113,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "✅",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "100",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "i-text",
                "left": -115,
                "top": 175,
                "angle": 0,
                "width": 100,
                "height": 113,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "❌",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "100",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "image",
                "left": 13,
                "top": -125,
                "angle": 0,
                "width": 200,
                "height": 200,
                "stroke": null,
                "strokeWidth": 0,
                "fill": "black",
                "src": "${ this.files[this.parameters.files] }",
                "autoScale": undefined
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {
              "happyf.jpeg": "embedded\u002Fb4ff102fb08de43ff1995674e7034ae9ae72cda5d16cab36fc140f2e886bc2de.jpeg"
            },
            "responses": {
              "click @no": "no",
              "click @yes": "yes"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Screen",
            "timeout": "100"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 150,
                "top": 175,
                "angle": 0,
                "width": 100,
                "height": 113,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "✅",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "100",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "i-text",
                "left": -115,
                "top": 175,
                "angle": 0,
                "width": 100,
                "height": 113,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "❌",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "100",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "i-text",
                "left": 11,
                "top": -125,
                "angle": 0,
                "width": 337.96,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "${this.parameters.word}",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "aoi",
                "left": -111.13,
                "top": 175,
                "angle": 0,
                "width": 124.26,
                "height": 124.26,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "no"
              },
              {
                "type": "aoi",
                "left": 148.13,
                "top": 175.13,
                "angle": 0,
                "width": 120.83,
                "height": 120.83,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "rgba(0, 0, 0, 0.2)",
                "label": "yes"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {
              "happyf.jpeg": "embedded\u002Fb4ff102fb08de43ff1995674e7034ae9ae72cda5d16cab36fc140f2e886bc2de.jpeg"
            },
            "responses": {
              "click @no": "no",
              "click @yes": "yes"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "Screen"
          }
        ]
      }
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())